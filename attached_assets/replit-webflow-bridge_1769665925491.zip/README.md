# Replit ↔ Webflow Bridge (Exact UI Preserved)

This repo connects your **existing Replit app** to **Webflow** WITHOUT changing how your app looks.

## Key Idea
- Your **Replit app remains the source of truth for UI**
- Webflow simply **embeds or talks to it**
- No redesign, no reimplementation

---

## Option A (Recommended): Keep the Exact Replit Look
Use an **iframe** in Webflow.

```html
<iframe
  src="https://YOUR-REPLIT-APP.replit.app"
  style="width:100%;height:100vh;border:none;"
  loading="lazy">
</iframe>
```

This guarantees your app looks **identical** to Replit.

---

## Option B: Webflow → Replit API
Use JS or Webflow Forms to send data.

Endpoint:
POST https://YOUR-REPLIT-APP.replit.app/api/submit

Headers:
x-api-key: your_secret_key_here

---

## Setup on Replit
1. Upload this repo or connect GitHub
2. Add Secrets:
   - PORT
   - API_KEY
3. Run `npm install`
4. Click Run

---

## What This Does NOT Do
- Does NOT alter your frontend
- Does NOT copy Webflow styles over Replit
- Does NOT break your existing app

It simply connects them cleanly.

---

Need auth, AI, CMS sync, or payments added?
You can extend `server.js` safely.