import express from "express";
import cors from "cors";
import dotenv from "dotenv";

dotenv.config();

const app = express();
app.use(cors());
app.use(express.json());

// Optional API key protection
app.use((req, res, next) => {
  const key = req.headers["x-api-key"];
  if (process.env.API_KEY && key !== process.env.API_KEY) {
    return res.status(401).json({ error: "Unauthorized" });
  }
  next();
});

// Health check
app.get("/api/status", (req, res) => {
  res.json({ status: "Connected", platform: "Replit" });
});

// Endpoint Webflow can call
app.post("/api/submit", (req, res) => {
  const payload = req.body;
  console.log("From Webflow:", payload);

  // TODO: plug in your existing Replit logic here
  // This does NOT change your UI — only backend communication

  res.json({
    ok: true,
    received: payload
  });
});

const PORT = process.env.PORT || 3000;
app.listen(PORT, () => {
  console.log(`API running on port ${PORT}`);
});