import express from "express";
import dotenv from "dotenv";
import { logEvent } from "./monitor.js";

dotenv.config();
const app = express();

app.use(express.json());

// Log all requests
app.use(async (req, res, next) => {
  await logEvent("REQUEST", {
    method: req.method,
    url: req.url,
    body: req.body,
    ip: req.ip
  });
  next();
});

app.post("/data", async (req, res) => {
  try {
    res.json({ status: "received" });
  } catch (err) {
    throw err;
  }
});

// Global error handler
app.use(async (err, req, res, next) => {
  await logEvent("ERROR", {
    message: err.message,
    stack: err.stack
  });

  res.status(500).json({
    error: "Something went wrong — issue logged and emailed"
  });
});

process.on("uncaughtException", async (err) => {
  await logEvent("ERROR", { fatal: err.message });
  process.exit(1);
});

process.on("unhandledRejection", async (reason) => {
  await logEvent("ERROR", { rejection: reason });
});

app.listen(3000, () => {
  console.log("Server running on port 3000");
});