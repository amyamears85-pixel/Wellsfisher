import nodemailer from "nodemailer";

const transporter = nodemailer.createTransport({
  service: "gmail",
  auth: {
    user: process.env.EMAIL_USER,
    pass: process.env.EMAIL_PASS
  }
});

export async function sendEmail(subject, message) {
  await transporter.sendMail({
    from: `"App Monitor" <${process.env.EMAIL_USER}>`,
    to: process.env.ADMIN_EMAIL,
    subject,
    text: message
  });
}

export async function logEvent(type, data) {
  const log = `
TYPE: ${type}
TIME: ${new Date().toISOString()}
DATA:
${JSON.stringify(data, null, 2)}
  `;

  console.log(log);

  if (type === "ERROR") {
    await sendEmail("🚨 App Error Detected", log);
  }
}